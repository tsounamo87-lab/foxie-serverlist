import { useEffect, useMemo, useState } from 'react'
import { AlertTriangle, SearchX, TrendingUp, WifiOff } from 'lucide-react'
import { Header } from './components/Header'
import { StatsBar } from './components/StatsBar'
import { FilterBar } from './components/FilterBar'
import { ServerCard } from './components/ServerCard'
import { ServerTable } from './components/ServerTable'
import { ServerDetailModal } from './components/ServerDetailModal'
import { SettingsPanel } from './components/SettingsPanel'
import { AlertsPanel } from './components/AlertsPanel'
import { Toaster } from './components/Toaster'
import { PopulationChart } from './components/charts'
import { useGames } from './lib/useGames'
import { usePlayers } from './lib/usePlayers'
import { enrichGames, type EnrichedGame } from './lib/players'
import { applyFilters, useFilters } from './store/filters'
import { applySettings, useSettings } from './store/settings'
import { useHistory } from './store/history'
import { useAlerts } from './store/alerts'
import { useToasts } from './store/toasts'

function App() {
  const { theme, font, effects, refreshSeconds } = useSettings()
  const { servers, games, loading, error, fetchedAt, countdown, refresh } = useGames(refreshSeconds)
  const { data: playerData, available: playersAvailable } = usePlayers(refreshSeconds)
  const filters = useFilters()
  const rules = useAlerts((s) => s.rules)
  const globalHistory = useHistory((s) => s.global)

  const [settingsOpen, setSettingsOpen] = useState(false)
  const [alertsOpen, setAlertsOpen] = useState(false)
  const [showTrends, setShowTrends] = useState(false)
  const [selected, setSelected] = useState<EnrichedGame | null>(null)

  // Keep <html> data-* attributes in sync with settings.
  useEffect(() => {
    applySettings({ theme, font, effects })
  }, [theme, font, effects])

  const enriched = useMemo(() => enrichGames(games, playerData), [games, playerData])
  const visible = useMemo(() => applyFilters(enriched, filters), [enriched, filters])

  // On each server-list refresh: record history + evaluate alerts.
  useEffect(() => {
    if (!fetchedAt) return
    const totalPlayers = servers.reduce((sum, s) => sum + s.current_players, 0)
    const perSystem: [string, number][] = enriched.map((g) => [
      g.key,
      g.livePlayers ? g.livePlayers.length : g.players,
    ])
    useHistory.getState().record(totalPlayers, games.length, perSystem)

    const events = useAlerts.getState().check(enriched, playerData?.byKey ?? null)
    for (const ev of events) {
      useToasts.getState().push({ message: ev.message, detail: ev.detail })
      if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
        new Notification(ev.message, { body: ev.detail })
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchedAt])

  // Keep the open modal's player data fresh as polls come in.
  useEffect(() => {
    if (!selected) return
    const fresh = enriched.find((g) => g.key === selected.key)
    if (fresh && fresh !== selected) setSelected(fresh)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enriched])

  return (
    <div className="min-h-screen">
      <Header
        loading={loading}
        countdown={countdown}
        alertCount={rules.filter((r) => r.enabled).length}
        onRefresh={refresh}
        onOpenSettings={() => setSettingsOpen(true)}
        onOpenAlerts={() => setAlertsOpen(true)}
      />

      <main className="mx-auto max-w-7xl space-y-5 px-4 py-5 sm:px-6">
        <StatsBar servers={servers} games={games} />

        {/* Live-data availability + trends toggle */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {!playersAvailable && (
            <span className="flex items-center gap-1.5 rounded-full border border-warning/40 bg-warning/10 px-3 py-1 text-warning">
              <WifiOff className="size-3.5" />
              Live player feed unavailable — showing official counts only
            </span>
          )}
          <button
            onClick={() => setShowTrends((v) => !v)}
            className={`flex items-center gap-1.5 rounded-full border px-3 py-1 transition-colors ${showTrends ? 'border-accent bg-accent-soft text-accent' : 'border-border text-muted hover:text-text'}`}
          >
            <TrendingUp className="size-3.5" />
            {showTrends ? 'Hide trends' : 'Show population trends'}
          </button>
        </div>

        {showTrends && (
          <div className="rounded-[var(--radius-app)] border border-border bg-surface/70 p-4 backdrop-blur">
            <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">
              Total players online over time
            </div>
            <PopulationChart samples={globalHistory} height={140} />
          </div>
        )}

        <FilterBar />

        {error && (
          <div className="flex items-center gap-2 rounded-[var(--radius-app)] border border-danger/40 bg-danger/10 px-4 py-3 text-sm text-danger">
            <AlertTriangle className="size-4" />
            Failed to load server data: {error}
          </div>
        )}

        <div className="flex items-center justify-between text-xs text-muted">
          <span>
            Showing <span className="font-semibold text-text">{visible.length}</span> of{' '}
            {games.length} systems
          </span>
        </div>

        {/* Results */}
        {loading && games.length === 0 ? (
          <SkeletonGrid />
        ) : visible.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-20 text-center text-muted">
            <SearchX className="size-8" />
            <p className="text-sm">No systems match your filters.</p>
          </div>
        ) : filters.view === 'table' ? (
          <ServerTable games={visible} onOpen={setSelected} />
        ) : filters.view === 'grouped' ? (
          <GroupedView games={visible} onOpen={setSelected} />
        ) : (
          <CardGrid games={visible} onOpen={setSelected} />
        )}
      </main>

      <SettingsPanel open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <AlertsPanel open={alertsOpen} onClose={() => setAlertsOpen(false)} />
      <Toaster />
      {selected && <ServerDetailModal game={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}

function CardGrid({ games, onOpen }: { games: EnrichedGame[]; onOpen: (g: EnrichedGame) => void }) {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {games.map((g) => (
        <ServerCard key={g.key} game={g} onOpen={() => onOpen(g)} />
      ))}
    </div>
  )
}

function GroupedView({ games, onOpen }: { games: EnrichedGame[]; onOpen: (g: EnrichedGame) => void }) {
  const groups = useMemo(() => {
    const map = new Map<string, EnrichedGame[]>()
    for (const g of games) {
      const arr = map.get(g.location) ?? []
      arr.push(g)
      map.set(g.location, arr)
    }
    return [...map.entries()].sort((a, b) => b[1].length - a[1].length)
  }, [games])

  return (
    <div className="space-y-6">
      {groups.map(([region, list]) => (
        <section key={region}>
          <div className="mb-2 flex items-center gap-2">
            <h2 className="text-sm font-bold uppercase tracking-wide text-text">{region}</h2>
            <span className="rounded-full bg-surface-2 px-2 py-0.5 text-xs text-muted">
              {list.length} systems · {list.reduce((s, g) => s + (g.livePlayers?.length ?? g.players), 0)} players
            </span>
          </div>
          <CardGrid games={list} onOpen={onOpen} />
        </section>
      ))}
    </div>
  )
}

function SkeletonGrid() {
  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div
          key={i}
          className="h-36 animate-pulse rounded-[var(--radius-app)] border border-border bg-surface/60"
        />
      ))}
    </div>
  )
}

export default App
