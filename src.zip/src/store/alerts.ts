import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { GameEntry } from '../lib/starblast'
import type { Player } from '../lib/players'

export type AlertType = 'player' | 'population'

export interface AlertRule {
  id: string
  type: AlertType
  /** player: name substring to watch. */
  query: string
  /** population: minimum players in a single system. */
  threshold: number
  enabled: boolean
}

export interface AlertEvent {
  id: string
  ruleId: string
  message: string
  detail: string
  at: number
}

interface AlertsState {
  rules: AlertRule[]
  /** debounce: ruleId -> signature of the current match */
  seen: Record<string, string>
  addPlayerRule: (query: string) => void
  addPopulationRule: (threshold: number) => void
  removeRule: (id: string) => void
  toggleRule: (id: string) => void
  /** Evaluate rules against the latest data; returns newly-fired events. */
  check: (games: GameEntry[], playersByKey: Map<string, Player[]> | null) => AlertEvent[]
}

const uid = () => Math.random().toString(36).slice(2, 9)

export const useAlerts = create<AlertsState>()(
  persist(
    (set, get) => ({
      rules: [],
      seen: {},
      addPlayerRule: (query) =>
        set((s) => ({
          rules: [
            ...s.rules,
            { id: uid(), type: 'player', query: query.trim(), threshold: 0, enabled: true },
          ],
        })),
      addPopulationRule: (threshold) =>
        set((s) => ({
          rules: [
            ...s.rules,
            { id: uid(), type: 'population', query: '', threshold, enabled: true },
          ],
        })),
      removeRule: (id) =>
        set((s) => ({ rules: s.rules.filter((r) => r.id !== id) })),
      toggleRule: (id) =>
        set((s) => ({
          rules: s.rules.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r)),
        })),
      check: (games, playersByKey) => {
        const { rules, seen } = get()
        const events: AlertEvent[] = []
        const nextSeen = { ...seen }

        for (const rule of rules) {
          if (!rule.enabled) continue

          if (rule.type === 'player') {
            if (!playersByKey || !rule.query) continue
            const q = rule.query.toLowerCase()
            let hit: { name: string; game: GameEntry } | null = null
            for (const g of games) {
              const players = playersByKey.get(g.key)
              if (!players) continue
              const p = players.find((pl) => pl.player_name.toLowerCase().includes(q))
              if (p) {
                hit = { name: p.player_name, game: g }
                break
              }
            }
            const sig = hit ? hit.game.key : ''
            if (hit && nextSeen[rule.id] !== sig) {
              events.push({
                id: uid(),
                ruleId: rule.id,
                message: `Player online: ${hit.name}`,
                detail: `In ${hit.game.name || 'system'} #${hit.game.id} (${hit.game.location})`,
                at: Date.now(),
              })
            }
            nextSeen[rule.id] = sig
          }

          if (rule.type === 'population') {
            const g = games.find((x) => x.players >= rule.threshold)
            const sig = g ? g.key : ''
            if (g && nextSeen[rule.id] !== sig) {
              events.push({
                id: uid(),
                ruleId: rule.id,
                message: `Server hit ${rule.threshold}+ players`,
                detail: `${g.name || 'System'} #${g.id} — ${g.players} players`,
                at: Date.now(),
              })
            }
            nextSeen[rule.id] = sig
          }
        }

        if (events.length) set({ seen: nextSeen })
        return events
      },
    }),
    { name: 'foxie-alerts', partialize: (s) => ({ rules: s.rules }) }
  )
)
