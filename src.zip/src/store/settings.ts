import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const THEMES = ['fox', 'midnight', 'nebula', 'terminal', 'daylight'] as const
export type Theme = (typeof THEMES)[number]

export const FONTS = ['inter', 'space', 'sora', 'mono'] as const
export type Font = (typeof FONTS)[number]

export const THEME_META: Record<Theme, { label: string; swatch: string }> = {
  fox: { label: 'Fox', swatch: '#ff7a2f' },
  midnight: { label: 'Midnight', swatch: '#38bdf8' },
  nebula: { label: 'Nebula', swatch: '#c084fc' },
  terminal: { label: 'Terminal', swatch: '#3ddc84' },
  daylight: { label: 'Daylight', swatch: '#e9610f' },
}

export const FONT_META: Record<Font, { label: string }> = {
  inter: { label: 'Inter' },
  space: { label: 'Space Grotesk' },
  sora: { label: 'Sora' },
  mono: { label: 'JetBrains Mono' },
}

interface SettingsState {
  theme: Theme
  font: Font
  effects: boolean
  refreshSeconds: number
  setTheme: (t: Theme) => void
  setFont: (f: Font) => void
  setEffects: (e: boolean) => void
  setRefreshSeconds: (n: number) => void
}

export const useSettings = create<SettingsState>()(
  persist(
    (set) => ({
      theme: 'fox',
      font: 'inter',
      effects: true,
      refreshSeconds: 10,
      setTheme: (theme) => set({ theme }),
      setFont: (font) => set({ font }),
      setEffects: (effects) => set({ effects }),
      setRefreshSeconds: (refreshSeconds) => set({ refreshSeconds }),
    }),
    { name: 'foxie-settings' }
  )
)

/** Push the current settings onto the <html> element's data-* attributes. */
export function applySettings(s: Pick<SettingsState, 'theme' | 'font' | 'effects'>) {
  const el = document.documentElement
  el.dataset.theme = s.theme
  el.dataset.font = s.font
  el.dataset.effects = s.effects ? 'on' : 'off'
}
