import { Clock, Copy, ExternalLink, Star, Users, ShieldAlert, Lock, Radio } from 'lucide-react'
import { useMemo, useState } from 'react'
import { formatUptime, modeLabel } from '../lib/starblast'
import type { EnrichedGame } from '../lib/players'
import { aggregateClans } from '../lib/clans'
import { useFilters } from '../store/filters'

const REGION_SHORT: Record<string, string> = { America: 'NA', Europe: 'EU', Asia: 'AS' }

export function ServerCard({ game, onOpen }: { game: EnrichedGame; onOpen: () => void }) {
  const favorites = useFilters((s) => s.favorites)
  const toggleFavorite = useFilters((s) => s.toggleFavorite)
  const isFav = favorites.includes(game.key)
  const [copied, setCopied] = useState(false)

  const live = game.livePlayers
  const playerCount = live ? live.length : game.players
  const clans = useMemo(() => (live ? aggregateClans(live) : []), [live])

  const copyLink = async (e: React.MouseEvent) => {
    e.stopPropagation()
    await navigator.clipboard.writeText(game.joinUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 1200)
  }

  const fill = Math.min(100, Math.round((playerCount / 90) * 100))

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onOpen}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onOpen())}
      className="fx-glow animate-fade-up group relative flex cursor-pointer flex-col gap-3 rounded-[var(--radius-app)] border border-border bg-surface/80 p-4 text-left backdrop-blur transition-colors hover:border-accent/60 focus:outline-none focus-visible:border-accent"
    >
      {/* Top row: name + favorite */}
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="truncate text-[15px] font-semibold leading-tight text-text">
              {game.name || `System ${game.id}`}
            </h3>
            {!game.open && <Lock className="size-3.5 shrink-0 text-muted" />}
            {live && (
              <span className="flex shrink-0 items-center gap-1 text-[10px] font-semibold uppercase text-success" title="Live player data">
                <Radio className="live-dot size-3" />
                Live
              </span>
            )}
          </div>
          <div className="mt-0.5 flex items-center gap-1.5 text-xs text-muted">
            <span className="rounded bg-surface-2 px-1.5 py-0.5 font-medium text-accent-2">{modeLabel(game)}</span>
            <span>#{game.id}</span>
            <span className="text-border">|</span>
            <span>{REGION_SHORT[game.location] ?? game.location}</span>
          </div>
        </div>
        <span
          onClick={(e) => { e.stopPropagation(); toggleFavorite(game.key) }}
          className="shrink-0 rounded-md p-1 text-muted transition-colors hover:bg-surface-2 hover:text-accent"
          title={isFav ? 'Remove favorite' : 'Add favorite'}
        >
          <Star className={`size-4 ${isFav ? 'fill-accent text-accent' : ''}`} />
        </span>
      </div>

      {/* Player fill bar */}
      <div>
        <div className="mb-1 flex items-center justify-between text-xs">
          <span className="flex items-center gap-1 font-medium text-text">
            <Users className="size-3.5 text-muted" />
            {playerCount}
            <span className="text-muted">players</span>
          </span>
          <span className="flex items-center gap-1 text-muted">
            <Clock className="size-3.5" />
            {formatUptime(game.time)}
          </span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
          <div className="h-full rounded-full bg-accent transition-all" style={{ width: `${fill}%` }} />
        </div>
      </div>

      {/* Footer: clans / criminal + actions */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs text-muted">
          <span className="flex items-center gap-1" title="Criminal activity level">
            <ShieldAlert className={`size-3.5 ${game.criminal_activity > 3 ? 'text-danger' : 'text-muted'}`} />
            {game.criminal_activity}
          </span>
          {clans.length > 0 && (
            <span className="rounded-full border border-border px-1.5 py-0.5 text-[10px]" title={clans.map((c) => `${c.tag} (${c.count})`).join(', ')}>
              {clans.length} clan{clans.length > 1 ? 's' : ''}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1.5">
          <span onClick={copyLink} className="flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs text-muted transition-colors hover:border-accent/50 hover:text-text">
            <Copy className="size-3.5" />
            {copied ? 'Copied' : 'Link'}
          </span>
          <a href={game.joinUrl} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="flex items-center gap-1 rounded-md bg-accent px-2.5 py-1 text-xs font-semibold text-bg transition-opacity hover:opacity-90">
            Join
            <ExternalLink className="size-3.5" />
          </a>
        </div>
      </div>
    </div>
  )
}
