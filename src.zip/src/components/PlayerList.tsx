import { useMemo, useState } from 'react'
import { Filter, Users } from 'lucide-react'
import { playerColor, type Player } from '../lib/players'
import { detectClan } from '../lib/clans'
import { Badge } from './Badge'

const MEDAL = ['#ffd24a', '#cdd4dc', '#cd8b54'] // gold / silver / bronze

export function PlayerList({ players }: { players: Player[] }) {
  const [clan, setClan] = useState('all')

  const clans = useMemo(() => {
    const set = new Set<string>()
    for (const p of players) {
      const t = detectClan(p.player_name)
      if (t) set.add(t)
    }
    return [...set].sort()
  }, [players])

  const sorted = useMemo(() => {
    const arr = clan === 'all' ? players : players.filter((p) => detectClan(p.player_name) === clan)
    return [...arr].sort((a, b) => b.score - a.score)
  }, [players, clan])

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <Users className="size-4 text-accent" />
        <span className="text-sm font-bold text-text">Players</span>
        <span className="ml-auto text-xs text-muted">{players.length} online</span>
      </div>

      {/* Clan filter */}
      <div className="flex items-center gap-2 border-b border-border px-4 py-2">
        <Filter className="size-3.5 text-muted" />
        <select
          value={clan}
          onChange={(e) => setClan(e.target.value)}
          className="flex-1 rounded-md border border-border bg-surface-2 px-2 py-1 text-xs text-text outline-none focus:border-accent"
        >
          <option value="all">All Players</option>
          {clans.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <span className="text-[11px] text-muted">
          {clans.length} clan{clans.length === 1 ? '' : 's'}
        </span>
      </div>

      {/* Rows */}
      <div className="min-h-0 flex-1 overflow-y-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-surface text-[10px] uppercase tracking-wide text-muted">
            <tr>
              <th className="px-4 py-1.5 text-left font-medium">Name</th>
              <th className="px-2 py-1.5 text-right font-medium" title="Kills">K</th>
              <th className="px-4 py-1.5 text-right font-medium">Score</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((p, i) => {
              const tag = detectClan(p.player_name)
              return (
                <tr
                  key={p.id}
                  className={`border-t border-border/60 ${p.isAlive ? '' : 'opacity-45'}`}
                >
                  <td className="px-4 py-1.5">
                    <span className="flex items-center gap-2">
                      {p.custom?.badge ? (
                        <Badge code={p.custom.badge} className="size-5 rounded-full" />
                      ) : (
                        <span
                          className="size-2 shrink-0 rounded-full"
                          style={{ background: playerColor(p.hue, p.isAlive) }}
                        />
                      )}
                      <span className="truncate text-text" style={{ color: i < 3 ? MEDAL[i] : undefined }}>
                        {p.player_name || 'Unknown'}
                      </span>
                      {tag && (
                        <span className="shrink-0 rounded bg-surface-2 px-1 text-[9px] text-muted">{tag}</span>
                      )}
                    </span>
                  </td>
                  <td className="px-2 py-1.5 text-right tabular-nums text-muted">{p.kills}</td>
                  <td className="px-4 py-1.5 text-right font-medium tabular-nums text-accent">
                    {p.score.toLocaleString()}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
