import { useMemo } from 'react'
import { Clock, Copy, ExternalLink, MapPin, Radio, ShieldAlert, Skull, Users, X } from 'lucide-react'
import { formatUptime, modeLabel } from '../lib/starblast'
import { summarizePlayers, type EnrichedGame, type Player } from '../lib/players'
import { useGameRelay } from '../lib/useGameRelay'
import { useHistory } from '../store/history'
import { GameMap } from './GameMap'
import { TeamSidebar } from './TeamSidebar'
import { PlayerList } from './PlayerList'
import { Sparkline } from './charts'

export function ServerDetailModal({
  game,
  onClose,
}: {
  game: EnrichedGame
  onClose: () => void
}) {
  const isTeam = game.mode === 'team'
  const history = useHistory((s) => s.perSystem[game.key])

  // Relay only for team-mode systems (dankdmitron only spectates team games).
  const relay = useGameRelay(isTeam ? game.key : null)

  // Players: prefer relay positions (real); fall back to pixelmelt snapshot.
  // For kills: relay has none — try to merge from pixelmelt by name match.
  const players = useMemo(() => {
    const relayList = relay.players
    const pmList = game.livePlayers ?? []
    if (!relayList) return pmList
    if (!pmList.length) return relayList
    const killsByName = new Map(
      pmList.map((p) => [p.player_name.toLowerCase().trim(), p.kills])
    )
    return relayList.map((p) => ({
      ...p,
      kills: killsByName.get(p.player_name.toLowerCase().trim()) ?? p.kills,
    }))
  }, [relay.players, game.livePlayers])

  const stats = useMemo(() => summarizePlayers(players), [players])
  const hasLive = relay.players !== null || (game.livePlayers?.length ?? 0) > 0

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/70 p-3 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="animate-fade-up flex max-h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-[var(--radius-app)] border border-border bg-surface shadow-2xl"
      >
        {/* ── Header ─────────────────────────────────────── */}
        <div className="flex items-start justify-between gap-3 border-b border-border p-4">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wide text-muted">
              <MapPin className="size-3.5" /> Game Overview
              {isTeam && relay.connected && (
                <span className="ml-1 flex items-center gap-1 text-success">
                  <Radio className="live-dot size-3" />
                  {relay.modeInfo ? 'Real map · live relay' : 'Connecting…'}
                </span>
              )}
            </div>
            <h2 className="truncate text-lg font-bold text-text">{game.name || `System ${game.id}`}</h2>
            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted">
              <span className="rounded bg-surface-2 px-1.5 py-0.5 font-medium text-accent-2">{modeLabel(game)}</span>
              <span>#{game.id}</span>
              <span className="text-border">|</span>
              <span>{game.location}</span>
              <span className="text-border">|</span>
              <span className="flex items-center gap-1"><Clock className="size-3" />{formatUptime(game.time)}</span>
              <span className="text-border">|</span>
              <span className="flex items-center gap-1"><ShieldAlert className="size-3" />crime {game.criminal_activity}</span>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <a href={game.joinUrl} target="_blank" rel="noreferrer"
              className="flex items-center gap-1 rounded-md bg-accent px-3 py-1.5 text-xs font-semibold text-bg hover:opacity-90">
              Join <ExternalLink className="size-3.5" />
            </a>
            <button onClick={() => navigator.clipboard.writeText(game.joinUrl)}
              className="rounded-md border border-border p-1.5 text-muted hover:text-text" title="Copy link">
              <Copy className="size-4" />
            </button>
            <button onClick={onClose} className="rounded-md border border-border p-1.5 text-muted hover:text-text">
              <X className="size-4" />
            </button>
          </div>
        </div>

        {/* ── Body ───────────────────────────────────────── */}
        {!hasLive ? (
          <div className="flex flex-col items-center gap-2 px-5 py-20 text-center text-muted">
            <Radio className="size-8" />
            <p className="text-sm">No live data for this system.</p>
            <p className="text-xs">{game.players} player(s) reported by official status.</p>
          </div>
        ) : isTeam ? (
          /* ── TEAM MODE: map + team sidebar ─────────── */
          <div className="grid min-h-0 flex-1 overflow-hidden md:grid-cols-[1fr_320px]">
            {/* Left: map + stats */}
            <div className="flex min-w-0 flex-col gap-3 overflow-y-auto p-4">
              <div className="flex justify-center">
                <GameMap
                  players={players}
                  mode={game.mode}
                  size={520}
                  modeInfo={relay.modeInfo}
                  asteroidGrid={relay.asteroidGrid}
                />
              </div>
              <MiniStats players={players} stats={stats} game={game} history={history} />
            </div>
            {/* Right: team sidebar */}
            <div className="min-h-0 border-t border-border md:border-l md:border-t-0">
              <TeamSidebar
                players={players}
                modeInfo={relay.modeInfo}
                teamStats={relay.teamStats}
              />
            </div>
          </div>
        ) : (
          /* ── OTHER MODES: no map, just stats + player list ── */
          <div className="grid min-h-0 flex-1 overflow-hidden md:grid-cols-[1fr_280px]">
            <div className="flex min-w-0 flex-col gap-3 overflow-y-auto p-4">
              <MiniStats players={players} stats={stats} game={game} history={history} />
            </div>
            <div className="min-h-0 border-t border-border md:border-l md:border-t-0">
              <PlayerList players={players} />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function MiniStats({
  players, stats, game, history,
}: {
  players: Player[]
  stats: ReturnType<typeof summarizePlayers>
  game: EnrichedGame
  history: { players: number }[] | undefined
}) {
  return (
    <>
      <div className="grid grid-cols-4 gap-2">
        <MiniStat icon={<Users className="size-3.5" />} label="Online" value={players.length} />
        <MiniStat icon={<Skull className="size-3.5" />} label="Alive" value={`${stats.alive}/${players.length}`} />
        <MiniStat icon={<ExternalLink className="size-3.5" />} label="Top score" value={stats.topScore.toLocaleString()} />
        <MiniStat icon={<Clock className="size-3.5" />} label="Uptime" value={formatUptime(game.time)} />
      </div>
      <div className="rounded-lg border border-border bg-surface-2 p-3">
        <div className="mb-1 text-[11px] uppercase tracking-wide text-muted">Population over time</div>
        <Sparkline values={(history ?? []).map((s) => s.players)} width={460} height={44} />
      </div>
    </>
  )
}

function MiniStat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="rounded-lg border border-border bg-surface-2 px-3 py-2">
      <div className="flex items-center gap-1 text-[11px] uppercase tracking-wide text-muted">{icon}{label}</div>
      <div className="mt-0.5 text-base font-bold tabular-nums text-text">{value}</div>
    </div>
  )
}
