import { useEffect, useMemo, useRef, useState } from 'react'
import { playerColor, type Player } from '../lib/players'
import { shipGlyph } from '../lib/ships'
import { Badge } from './Badge'
import type { RelayModeInfo } from '../lib/useGameRelay'

// ─── Smooth 60fps position interpolation ─────────────────────────────────────
// alpha=0.5 → 50% closure per frame: ships reach their target within the time
// between two relay frames regardless of relay speed (10-30fps).
const ALPHA = 0.5
const SNAP_DST = 200 // world units — snap immediately on first appear / teleport

function useSmoothedPositions(players: Player[]): Player[] {
  const playersRef = useRef<Player[]>([])
  const displayRef = useRef<Map<number, { x: number; y: number }>>(new Map())
  const [output, setOutput] = useState<Player[]>([])
  const rafRef = useRef(0)

  useEffect(() => { playersRef.current = players }, [players])

  useEffect(() => {
    const loop = () => {
      const targets = playersRef.current
      const disp = displayRef.current
      const alive = new Set(targets.map((p) => p.id))
      let changed = false

      for (const id of disp.keys()) {
        if (!alive.has(id)) { disp.delete(id); changed = true }
      }
      for (const p of targets) {
        const cur = disp.get(p.id)
        if (!cur) { disp.set(p.id, { x: p.x, y: p.y }); changed = true; continue }
        const dist = Math.sqrt((p.x - cur.x) ** 2 + (p.y - cur.y) ** 2)
        if (dist > SNAP_DST) {
          disp.set(p.id, { x: p.x, y: p.y }); changed = true
        } else if (dist > 0.05) {
          disp.set(p.id, {
            x: cur.x + (p.x - cur.x) * ALPHA,
            y: cur.y + (p.y - cur.y) * ALPHA,
          })
          changed = true
        }
      }

      if (changed) {
        setOutput(
          targets.map((p) => {
            const d = disp.get(p.id)
            return d ? { ...p, x: d.x, y: d.y } : p
          })
        )
      }
      rafRef.current = requestAnimationFrame(loop)
    }
    rafRef.current = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(rafRef.current)
  }, [])

  return output
}

// ─── Asteroid grid → renderable circles ──────────────────────────────────────
function useAsteroids(grid: string | null | undefined, mapSize: number) {
  return useMemo(() => {
    if (!grid || !mapSize) return null
    const rows = grid.split('\n')
    const cellPct = 100 / mapSize
    const dots: { cx: number; cy: number; r: number }[] = []
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i]
      for (let j = 0; j < row.length; j++) {
        const d = row.charCodeAt(j) - 48
        if (d > 0) {
          dots.push({
            cx: (j + 0.5) * cellPct,
            cy: (i + 0.5) * cellPct,
            r: (d / 10) * (cellPct / 2),
          })
        }
      }
    }
    return dots
  }, [grid, mapSize])
}

// ─── Deterministic starfield (fallback when no relay) ─────────────────────────
function useStars(count: number) {
  return useMemo(() => {
    let seed = 1337
    const rng = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff }
    return Array.from({ length: count }, () => ({ x: rng()*100, y: rng()*100, r: rng()*1.1+0.2, o: rng()*0.5+0.15 }))
  }, [count])
}

// ─── Main component ───────────────────────────────────────────────────────────
export function GameMap({
  players,
  mode,
  size = 560,
  modeInfo,
  asteroidGrid,
}: {
  players: Player[]
  mode: string
  size?: number
  modeInfo?: RelayModeInfo | null
  asteroidGrid?: string | null
}) {
  const smoothed = useSmoothedPositions(players)
  const stars = useStars(260)
  const asteroidDots = useAsteroids(asteroidGrid, modeInfo?.mapSize ?? 0)
  const hasRealMap = !!asteroidDots

  // World half-extent
  const half = useMemo(() => {
    if (modeInfo) return modeInfo.mapSize * 5
    let m = 160
    for (const p of players) m = Math.max(m, Math.abs(p.x), Math.abs(p.y))
    return Math.ceil((m * 1.12) / 40) * 40
  }, [players, modeInfo])

  const project = (x: number, y: number) => ({
    left: ((x + half) / (half * 2)) * 100,
    top: (1 - (y + half) / (half * 2)) * 100,
  })

  // Team stations (rotate over time from relay clock)
  const stations = useMemo(() => {
    if (!modeInfo?.teams?.length) return []
    const radius = (Math.sqrt(2) / 2) * half
    const steps = (modeInfo.servertime + (Date.now() - modeInfo.obtainedAt)) / 1000 * 60
    const theta = ((steps / 60 / 3600) % 1) * Math.PI * 2
    return modeInfo.teams.map((t) => {
      const a = theta + t.phase
      return { hue: t.hue, ...project(radius * Math.cos(a), radius * Math.sin(a)) }
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modeInfo, half])

  const gridLines = [12.5, 25, 37.5, 50, 62.5, 75, 87.5]

  return (
    <div
      className="relative overflow-hidden rounded-lg border border-border bg-black"
      style={{ width: size, height: size, maxWidth: '100%', aspectRatio: '1 / 1' }}
    >
      <svg className="absolute inset-0 size-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        {hasRealMap
          ? asteroidDots!.map((a, i) => (
              <circle key={i} cx={a.cx} cy={a.cy} r={a.r} fill="#8899aa" opacity="0.55" />
            ))
          : stars.map((s, i) => (
              <circle key={i} cx={s.x} cy={s.y} r={s.r * 0.12} fill="#fff" opacity={s.o} />
            ))}
        {gridLines.map((g) => (
          <g key={g} stroke="#ffffff" strokeWidth="0.1" opacity="0.06">
            <line x1={g} y1="0" x2={g} y2="100" />
            <line x1="0" y1={g} x2="100" y2={g} />
          </g>
        ))}
      </svg>

      {/* Team stations */}
      {stations.map((st, i) => (
        <div
          key={i}
          className="absolute -translate-x-1/2 -translate-y-1/2 rounded-[3px] ring-2 ring-white/40"
          style={{
            left: `${st.left}%`, top: `${st.top}%`,
            width: 14, height: 14,
            background: `hsl(${st.hue}, 80%, 50%)`,
            boxShadow: `0 0 12px hsl(${st.hue}, 80%, 50%)`,
          }}
          title="Station"
        />
      ))}

      {/* Ships — use smoothed (interpolated) positions */}
      {smoothed.map((p) => {
        const { left, top } = project(p.x, p.y)
        const glyph = shipGlyph(p.ship, mode)
        const color = playerColor(p.hue, p.isAlive)
        return (
          <div
            key={p.id}
            className="absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center"
            style={{ left: `${left}%`, top: `${top}%`, opacity: p.isAlive ? 1 : 0.4 }}
          >
            {glyph ? (
              <span style={{ fontFamily: 'StarblastVanilla', fontSize: 22, color, textShadow: `0 0 6px ${color}`, lineHeight: 1 }}>
                {glyph}
              </span>
            ) : (
              <span className="size-2.5 rounded-full" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
            )}
            <span className="mt-0.5 flex max-w-[120px] items-center gap-0.5 whitespace-nowrap text-[10px] leading-none text-white/90">
              {p.custom?.badge && <Badge code={p.custom.badge} className="size-3" />}
              <span className="truncate" style={{ textShadow: '0 1px 2px #000' }}>{p.player_name || '???'}</span>
            </span>
          </div>
        )
      })}

      {players.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center text-sm text-muted">
          Waiting for positions…
        </div>
      )}
    </div>
  )
}
