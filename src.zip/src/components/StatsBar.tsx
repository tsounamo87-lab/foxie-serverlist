import { Activity, Globe, Server as ServerIcon, Users } from 'lucide-react'
import type { GameEntry, Server } from '../lib/starblast'

function Stat({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode
  label: string
  value: string | number
}) {
  return (
    <div className="flex items-center gap-2.5 rounded-[var(--radius-app)] border border-border bg-surface/70 px-3.5 py-2.5 backdrop-blur">
      <span className="text-accent">{icon}</span>
      <div className="leading-none">
        <div className="text-lg font-bold tabular-nums text-text">{value}</div>
        <div className="mt-0.5 text-[11px] uppercase tracking-wide text-muted">{label}</div>
      </div>
    </div>
  )
}

export function StatsBar({ servers, games }: { servers: Server[]; games: GameEntry[] }) {
  const totalPlayers = servers.reduce((sum, s) => sum + s.current_players, 0)
  const regions = new Set(servers.map((s) => s.location)).size

  return (
    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
      <Stat icon={<Users className="size-5" />} label="Players online" value={totalPlayers} />
      <Stat icon={<Activity className="size-5" />} label="Active systems" value={games.length} />
      <Stat icon={<ServerIcon className="size-5" />} label="Servers" value={servers.length} />
      <Stat icon={<Globe className="size-5" />} label="Regions" value={regions} />
    </div>
  )
}
