import { ArrowUpDown, LayoutGrid, Layers, List, Search, Star, X } from 'lucide-react'
import { REGIONS } from '../lib/starblast'
import { useFilters, type SortKey, type ViewMode } from '../store/filters'

const MODES: { value: string; label: string }[] = [
  { value: 'team', label: 'Team' },
  { value: 'survival', label: 'Survival' },
  { value: 'deathmatch', label: 'Deathmatch' },
  { value: 'invasion', label: 'Invasion' },
  { value: 'modding', label: 'Modded' },
]

const SORTS: { value: SortKey; label: string }[] = [
  { value: 'players', label: 'Players' },
  { value: 'uptime', label: 'Uptime' },
  { value: 'name', label: 'Name' },
  { value: 'criminal', label: 'Criminal activity' },
]

const VIEWS: { value: ViewMode; label: string; icon: React.ReactNode }[] = [
  { value: 'grid', label: 'Grid', icon: <LayoutGrid className="size-4" /> },
  { value: 'table', label: 'Table', icon: <List className="size-4" /> },
  { value: 'grouped', label: 'Grouped by region', icon: <Layers className="size-4" /> },
]

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
        active
          ? 'border-accent bg-accent-soft text-accent'
          : 'border-border bg-surface text-muted hover:text-text'
      }`}
    >
      {children}
    </button>
  )
}

export function FilterBar() {
  const f = useFilters()

  return (
    <div className="flex flex-col gap-3">
      {/* Search */}
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
        <input
          value={f.search}
          onChange={(e) => f.setSearch(e.target.value)}
          placeholder="Search by name, mode, system id, region…"
          className="w-full rounded-[var(--radius-app)] border border-border bg-surface py-2.5 pl-10 pr-9 text-sm text-text outline-none transition-colors placeholder:text-muted focus:border-accent"
        />
        {f.search && (
          <button
            onClick={() => f.setSearch('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 text-muted hover:text-text"
          >
            <X className="size-4" />
          </button>
        )}
      </div>

      {/* Region + mode chips */}
      <div className="flex flex-wrap items-center gap-1.5">
        <Chip active={f.region === 'all'} onClick={() => f.setRegion('all')}>
          All regions
        </Chip>
        {REGIONS.map((r) => (
          <Chip key={r} active={f.region === r} onClick={() => f.setRegion(r)}>
            {r}
          </Chip>
        ))}
        <span className="mx-1 h-4 w-px bg-border" />
        {MODES.map((m) => (
          <Chip key={m.value} active={f.modes.includes(m.value)} onClick={() => f.toggleMode(m.value)}>
            {m.label}
          </Chip>
        ))}
      </div>

      {/* Toggles + sort */}
      <div className="flex flex-wrap items-center gap-1.5">
        <Chip active={f.favoritesOnly} onClick={() => f.setFavoritesOnly(!f.favoritesOnly)}>
          <span className="flex items-center gap-1">
            <Star className={`size-3 ${f.favoritesOnly ? 'fill-accent' : ''}`} />
            Favorites
          </span>
        </Chip>
        <Chip active={f.hideEmpty} onClick={() => f.setHideEmpty(!f.hideEmpty)}>
          Hide empty
        </Chip>
        <Chip active={f.openOnly} onClick={() => f.setOpenOnly(!f.openOnly)}>
          Open only
        </Chip>

        <div className="ml-auto flex items-center gap-2 text-xs text-muted">
          {/* View mode */}
          <div className="flex items-center rounded-md border border-border bg-surface p-0.5">
            {VIEWS.map((v) => (
              <button
                key={v.value}
                onClick={() => f.setView(v.value)}
                title={v.label}
                className={`rounded p-1 transition-colors ${f.view === v.value ? 'bg-accent-soft text-accent' : 'text-muted hover:text-text'}`}
              >
                {v.icon}
              </button>
            ))}
          </div>
          {/* Sort */}
          <div className="flex items-center gap-1.5">
            <ArrowUpDown className="size-3.5" />
            <select
              value={f.sort}
              onChange={(e) => f.setSort(e.target.value as SortKey)}
              className="rounded-md border border-border bg-surface px-2 py-1 text-text outline-none focus:border-accent"
            >
              {SORTS.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  )
}
