import { Bell, RefreshCw, Settings } from 'lucide-react'
import { FoxLogo } from './FoxLogo'

interface HeaderProps {
  loading: boolean
  countdown: number
  alertCount: number
  onRefresh: () => void
  onOpenSettings: () => void
  onOpenAlerts: () => void
}

export function Header({
  loading,
  countdown,
  alertCount,
  onRefresh,
  onOpenSettings,
  onOpenAlerts,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-20 border-b border-border bg-bg/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        <div className="flex items-center gap-2.5">
          <span className="fx-glow-text text-accent">
            <FoxLogo />
          </span>
          <div className="leading-none">
            <div className="text-base font-extrabold tracking-tight text-text">
              Foxie<span className="text-accent"> Server List</span>
            </div>
            <div className="mt-0.5 text-[11px] text-muted">Live Starblast servers</div>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={onOpenAlerts}
            className="relative rounded-lg border border-border bg-surface p-1.5 text-muted transition-colors hover:text-text"
            title="Alerts"
          >
            <Bell className="size-4" />
            {alertCount > 0 && (
              <span className="absolute -right-1 -top-1 flex size-4 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-bg">
                {alertCount}
              </span>
            )}
          </button>
          <button
            onClick={onRefresh}
            className="flex items-center gap-1.5 rounded-lg border border-border bg-surface px-2.5 py-1.5 text-xs text-muted transition-colors hover:text-text"
            title="Refresh now"
          >
            <RefreshCw className={`size-3.5 ${loading ? 'animate-spin text-accent' : ''}`} />
            <span className="tabular-nums">{loading ? 'Updating' : `${countdown}s`}</span>
          </button>
          <button
            onClick={onOpenSettings}
            className="rounded-lg border border-border bg-surface p-1.5 text-muted transition-colors hover:text-text"
            title="Settings"
          >
            <Settings className="size-4" />
          </button>
        </div>
      </div>
    </header>
  )
}
