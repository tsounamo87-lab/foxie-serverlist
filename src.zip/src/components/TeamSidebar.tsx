import { useMemo } from 'react'
import { Lock, Unlock } from 'lucide-react'
import type { Player } from '../lib/players'
import type { RelayModeInfo, TeamStat } from '../lib/useGameRelay'
import { detectClan } from '../lib/clans'
import { shipGlyph } from '../lib/ships'
import { playerColor } from '../lib/players'
import { Badge } from './Badge'

const MEDAL = ['#ffd24a', '#cdd4dc', '#cd8b54']

interface TeamGroup {
  hue: number
  statIdx: number
  players: Player[]
  totalScore: number
  ecpCount: number
}

/** Convert hue → approximate colour name. */
function teamColorName(hue: number): string {
  if (hue < 20 || hue >= 340) return 'Red'
  if (hue < 50) return 'Orange'
  if (hue < 80) return 'Yellow'
  if (hue < 160) return 'Green'
  if (hue < 200) return 'Teal'
  if (hue < 260) return 'Blue'
  if (hue < 290) return 'Violet'
  if (hue < 340) return 'Pink'
  return 'Red'
}

export function TeamSidebar({
  players,
  modeInfo,
  teamStats,
}: {
  players: Player[]
  modeInfo: RelayModeInfo | null
  teamStats: TeamStat[] | null
}) {
  const teams = useMemo<TeamGroup[]>(() => {
    if (!modeInfo?.teams?.length) return []
    return modeInfo.teams
      .map((t, idx) => {
        const members = players.filter((p) => p.hue === t.hue).sort((a, b) => b.score - a.score)
        return {
          hue: t.hue,
          statIdx: idx,
          players: members,
          totalScore: members.reduce((s, p) => s + p.score, 0),
          ecpCount: members.filter((p) => p.custom).length,
        }
      })
      .sort((a, b) => b.totalScore - a.totalScore) // highest-score team first
  }, [players, modeInfo])

  if (!teams.length) {
    return (
      <div className="flex h-full items-center justify-center text-xs text-muted">
        Waiting for team data…
      </div>
    )
  }

  return (
    <div className="flex h-full min-h-0 flex-col overflow-y-auto">
      {teams.map((team) => {
        const stat = teamStats?.[team.statIdx]
        const teamColor = `hsl(${team.hue}, 75%, 62%)`

        return (
          <div key={team.hue}>
            {/* ── Team header (sticky) ───────────────────────── */}
            <div
              className="sticky top-0 z-10 border-b border-t border-border bg-surface px-3 py-1.5"
              style={{ borderLeftColor: teamColor, borderLeftWidth: 3 }}
            >
              <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-0.5">
                {/* Name + lock */}
                <span className="flex items-center gap-1 text-sm font-bold" style={{ color: teamColor }}>
                  {teamColorName(team.hue)}
                  {stat && (stat.open
                    ? <Unlock className="size-3 opacity-60" />
                    : <Lock className="size-3 opacity-60" />)}
                </span>
                {/* Stats */}
                <div className="flex items-center gap-3 text-[11px] text-muted">
                  <span title="ECP players">
                    ECP <span className="font-semibold text-text">{team.ecpCount}</span>
                  </span>
                  {stat && (
                    <>
                      <span title="Station level">
                        Lv <span className="font-semibold text-text">{stat.level}</span>
                      </span>
                      <span title="Team gems">
                        Gems <span className="font-semibold text-text">{stat.crystals.toLocaleString()}</span>
                      </span>
                    </>
                  )}
                  <span title="Total team score" className="font-semibold" style={{ color: teamColor }}>
                    {team.totalScore.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            {/* ── Player rows ───────────────────────────────── */}
            {team.players.map((p, i) => {
              const tag = detectClan(p.player_name)
              const glyph = shipGlyph(p.ship, 'team')
              const col = playerColor(p.hue, p.isAlive)
              const rankColor = i < 3 ? MEDAL[i] : undefined

              return (
                <div
                  key={p.id}
                  className={`flex items-center gap-1.5 border-b border-border/40 px-3 py-1 ${p.isAlive ? '' : 'opacity-45'}`}
                >
                  {/* Badge or dot */}
                  {p.custom?.badge
                    ? <Badge code={p.custom.badge} className="size-4 shrink-0" />
                    : <span className="size-2 shrink-0 rounded-full" style={{ background: col }} />}

                  {/* Ship glyph */}
                  {glyph && (
                    <span
                      className="shrink-0 leading-none"
                      style={{ fontFamily: 'StarblastVanilla', fontSize: 14, color: col }}
                    >
                      {glyph}
                    </span>
                  )}

                  {/* Name */}
                  <span
                    className="min-w-0 flex-1 truncate text-xs"
                    style={{ color: rankColor ?? `hsl(${team.hue}, 60%, 75%)` }}
                    title={p.player_name}
                  >
                    {p.player_name || '???'}
                    {tag && <span className="ml-1 text-[10px] opacity-50">[{tag}]</span>}
                  </span>

                  {/* Kills */}
                  {p.kills > 0 && (
                    <span className="shrink-0 text-[10px] tabular-nums text-danger/80">
                      {p.kills}K
                    </span>
                  )}

                  {/* Score */}
                  <span className="shrink-0 text-xs font-medium tabular-nums text-text/90">
                    {p.score.toLocaleString()}
                  </span>
                </div>
              )
            })}
          </div>
        )
      })}
    </div>
  )
}
