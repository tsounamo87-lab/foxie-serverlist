import { Check, X } from 'lucide-react'
import {
  FONTS,
  FONT_META,
  THEMES,
  THEME_META,
  useSettings,
} from '../store/settings'

export function SettingsPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const s = useSettings()

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        className={`fixed inset-0 z-30 bg-black/50 backdrop-blur-sm transition-opacity ${
          open ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      />
      {/* Drawer */}
      <aside
        className={`fixed right-0 top-0 z-40 flex h-full w-[min(360px,90vw)] flex-col border-l border-border bg-surface shadow-2xl transition-transform duration-300 ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="text-sm font-bold uppercase tracking-wide text-text">Appearance</h2>
          <button onClick={onClose} className="rounded-md p-1 text-muted hover:text-text">
            <X className="size-5" />
          </button>
        </div>

        <div className="flex-1 space-y-6 overflow-y-auto px-5 py-5">
          {/* Theme */}
          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Theme</h3>
            <div className="grid grid-cols-2 gap-2">
              {THEMES.map((t) => (
                <button
                  key={t}
                  onClick={() => s.setTheme(t)}
                  className={`flex items-center gap-2 rounded-lg border px-3 py-2.5 text-sm transition-colors ${
                    s.theme === t
                      ? 'border-accent bg-accent-soft text-text'
                      : 'border-border bg-surface-2 text-muted hover:text-text'
                  }`}
                >
                  <span
                    className="size-4 shrink-0 rounded-full ring-2 ring-inset ring-white/10"
                    style={{ background: THEME_META[t].swatch }}
                  />
                  {THEME_META[t].label}
                  {s.theme === t && <Check className="ml-auto size-4 text-accent" />}
                </button>
              ))}
            </div>
          </section>

          {/* Font */}
          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Font</h3>
            <div className="grid grid-cols-2 gap-2">
              {FONTS.map((font) => (
                <button
                  key={font}
                  onClick={() => s.setFont(font)}
                  className={`rounded-lg border px-3 py-2.5 text-sm transition-colors ${
                    s.font === font
                      ? 'border-accent bg-accent-soft text-text'
                      : 'border-border bg-surface-2 text-muted hover:text-text'
                  }`}
                >
                  {FONT_META[font].label}
                </button>
              ))}
            </div>
          </section>

          {/* Effects */}
          <section className="flex items-center justify-between rounded-lg border border-border bg-surface-2 px-4 py-3">
            <div>
              <div className="text-sm font-medium text-text">Visual effects</div>
              <div className="text-xs text-muted">Glow, animations &amp; transitions</div>
            </div>
            <button
              onClick={() => s.setEffects(!s.effects)}
              className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${
                s.effects ? 'bg-accent' : 'bg-border'
              }`}
            >
              <span
                className={`absolute top-[2px] size-5 rounded-full bg-white transition-transform ${
                  s.effects ? 'translate-x-[22px]' : 'translate-x-[2px]'
                }`}
              />
            </button>
          </section>

          {/* Refresh interval */}
          <section>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-muted">
                Auto refresh
              </h3>
              <span className="text-xs tabular-nums text-accent">{s.refreshSeconds}s</span>
            </div>
            <input
              type="range"
              min={5}
              max={60}
              step={5}
              value={s.refreshSeconds}
              onChange={(e) => s.setRefreshSeconds(Number(e.target.value))}
              className="w-full accent-[var(--c-accent)]"
            />
          </section>
        </div>

        <div className="border-t border-border px-5 py-3 text-center text-[11px] text-muted">
          Data from the official Starblast server status
        </div>
      </aside>
    </>
  )
}
