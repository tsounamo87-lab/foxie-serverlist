import { useState } from 'react'
import { Bell, BellOff, Plus, Trash2, User, Users, X } from 'lucide-react'
import { useAlerts } from '../store/alerts'

export function AlertsPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { rules, addPlayerRule, addPopulationRule, removeRule, toggleRule } = useAlerts()
  const [name, setName] = useState('')
  const [threshold, setThreshold] = useState(50)
  const [notifGranted, setNotifGranted] = useState(
    typeof Notification !== 'undefined' && Notification.permission === 'granted'
  )

  const addPlayer = () => {
    if (name.trim()) {
      addPlayerRule(name)
      setName('')
    }
  }

  const requestNotif = async () => {
    if (typeof Notification === 'undefined') return
    const res = await Notification.requestPermission()
    setNotifGranted(res === 'granted')
  }

  return (
    <>
      <div
        onClick={onClose}
        className={`fixed inset-0 z-30 bg-black/50 backdrop-blur-sm transition-opacity ${open ? 'opacity-100' : 'pointer-events-none opacity-0'}`}
      />
      <aside
        className={`fixed left-0 top-0 z-40 flex h-full w-[min(380px,92vw)] flex-col border-r border-border bg-surface shadow-2xl transition-transform duration-300 ${open ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-text">
            <Bell className="size-4 text-accent" /> Alerts
          </h2>
          <button onClick={onClose} className="rounded-md p-1 text-muted hover:text-text">
            <X className="size-5" />
          </button>
        </div>

        <div className="flex-1 space-y-6 overflow-y-auto px-5 py-5">
          {/* Browser notifications */}
          <button
            onClick={requestNotif}
            disabled={notifGranted}
            className={`flex w-full items-center gap-2 rounded-lg border px-3 py-2.5 text-sm ${notifGranted ? 'border-success/40 text-success' : 'border-border text-muted hover:text-text'}`}
          >
            {notifGranted ? <Bell className="size-4" /> : <BellOff className="size-4" />}
            {notifGranted ? 'Desktop notifications enabled' : 'Enable desktop notifications'}
          </button>

          {/* Add player watch */}
          <section>
            <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted">
              <User className="size-3.5" /> Watch a player
            </h3>
            <div className="flex gap-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addPlayer()}
                placeholder="Player name contains…"
                className="flex-1 rounded-lg border border-border bg-surface-2 px-3 py-2 text-sm text-text outline-none focus:border-accent"
              />
              <button onClick={addPlayer} className="rounded-lg bg-accent px-3 text-bg hover:opacity-90">
                <Plus className="size-4" />
              </button>
            </div>
            <p className="mt-1 text-[11px] text-muted">Fires when a matching player appears in any system (needs live data).</p>
          </section>

          {/* Add population watch */}
          <section>
            <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted">
              <Users className="size-3.5" /> Population threshold
            </h3>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min={1}
                value={threshold}
                onChange={(e) => setThreshold(Number(e.target.value))}
                className="w-24 rounded-lg border border-border bg-surface-2 px-3 py-2 text-sm text-text outline-none focus:border-accent"
              />
              <span className="text-sm text-muted">players in a system</span>
              <button onClick={() => addPopulationRule(threshold)} className="ml-auto rounded-lg bg-accent px-3 py-2 text-bg hover:opacity-90">
                <Plus className="size-4" />
              </button>
            </div>
          </section>

          {/* Rule list */}
          <section>
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Active rules</h3>
            {rules.length === 0 ? (
              <p className="rounded-lg border border-dashed border-border px-3 py-4 text-center text-xs text-muted">No alerts yet.</p>
            ) : (
              <ul className="space-y-2">
                {rules.map((r) => (
                  <li key={r.id} className="flex items-center gap-2 rounded-lg border border-border bg-surface-2 px-3 py-2">
                    {r.type === 'player' ? <User className="size-4 text-accent-2" /> : <Users className="size-4 text-accent-2" />}
                    <span className="min-w-0 flex-1 truncate text-sm text-text">
                      {r.type === 'player' ? `"${r.query}"` : `${r.threshold}+ players`}
                    </span>
                    <button onClick={() => toggleRule(r.id)} className={`rounded p-1 ${r.enabled ? 'text-success' : 'text-muted'}`} title={r.enabled ? 'Enabled' : 'Disabled'}>
                      {r.enabled ? <Bell className="size-4" /> : <BellOff className="size-4" />}
                    </button>
                    <button onClick={() => removeRule(r.id)} className="rounded p-1 text-muted hover:text-danger">
                      <Trash2 className="size-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </aside>
    </>
  )
}
