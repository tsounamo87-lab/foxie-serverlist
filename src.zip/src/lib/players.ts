// ------------------------------------------------------------------
//  Live per-player data — enriches the simstatus server list.
//  Source: https://api.pixelmelt.dev/games  (CORS *, public)
//  Used only to ADD player detail (names, scores, radar positions);
//  the app still works without it (graceful degradation).
// ------------------------------------------------------------------

import type { GameEntry } from './starblast'

// The /players endpoint is richer than /games: a flat list of every player
// across all systems, each carrying its compositeId AND ECP `custom` data
// (badge / finish / laser), which /games omits.
export const PLAYERS_URL = 'https://api.pixelmelt.dev/players'

/** ECP customization attached to premium players. */
export interface PlayerCustom {
  badge?: string
  finish?: string
  laser?: string
  hue?: number
}

export interface Player {
  id: number
  player_name: string
  score: number
  ship: number
  hue: number
  isAlive: boolean
  x: number
  y: number
  custom: PlayerCustom | null
  friendly: number
  kills: number
  compositeId?: string
}

export interface PlayerData {
  /** compositeId (`id@server`) -> players */
  byKey: Map<string, Player[]>
  fetchedAt: number
}

export async function fetchPlayerData(signal?: AbortSignal): Promise<PlayerData> {
  const res = await fetch(PLAYERS_URL, { signal, cache: 'no-store' })
  if (!res.ok) throw new Error(`players ${res.status}`)
  const players: Player[] = await res.json()
  const byKey = new Map<string, Player[]>()
  for (const p of players) {
    if (!p.compositeId) continue
    const arr = byKey.get(p.compositeId)
    if (arr) {
      if (!arr.some((x) => x.id === p.id)) arr.push(p) // guard against dup ids
    } else {
      byKey.set(p.compositeId, [p])
    }
  }
  return { byKey, fetchedAt: Date.now() }
}

/** Image URL for an ECP badge code (e.g. "csf" -> .../ecp/csf.png). */
export function badgeUrl(badge: string): string {
  return `https://starblast.io/ecp/${badge}.png`
}

/** A server entry plus (optionally) its live player roster. */
export type EnrichedGame = GameEntry & { livePlayers?: Player[] }

/** Attach live player rosters to the server list by composite key. */
export function enrichGames(games: GameEntry[], data: PlayerData | null): EnrichedGame[] {
  if (!data) return games
  return games.map((g) => {
    const livePlayers = data.byKey.get(g.key)
    return livePlayers ? { ...g, livePlayers } : g
  })
}

/** Ship tier from a Starblast ship code (e.g. 701 -> 7). */
export function shipTier(ship: number): number {
  return Math.floor(ship / 100)
}

/** A player's display colour, derived from their in-game hue. */
export function playerColor(hue: number, alive = true): string {
  return `hsl(${hue}, ${alive ? 75 : 30}%, ${alive ? 58 : 40}%)`
}

export interface PlayerStats {
  alive: number
  dead: number
  topScore: number
  topKiller: Player | null
}

export function summarizePlayers(players: Player[]): PlayerStats {
  let alive = 0
  let topScore = 0
  let topKiller: Player | null = null
  for (const p of players) {
    if (p.isAlive) alive++
    if (p.score > topScore) topScore = p.score
    if (!topKiller || p.kills > topKiller.kills) topKiller = p
  }
  return { alive, dead: players.length - alive, topScore, topKiller }
}
