import { useEffect, useRef, useState } from 'react'
import type { Player, PlayerCustom } from './players'
import { getMap } from './mapGen'

// dankdmitron runs a public relay that spectates Starblast TEAM games and
// re-broadcasts mode info (seed, teams) + binary position frames. We read it
// directly from the browser — no backend of our own. Team mode only.
const DEFAULT_RELAY = 'wss://starblast.dankdmitron.dev/api/'
const RELAY_URL = (import.meta.env.VITE_RELAY_URL as string | undefined) || DEFAULT_RELAY

export interface Station {
  hue: number
  phase: number
}

export interface RelayModeInfo {
  seed: number
  mapSize: number
  modeId: string
  teams: Station[]
  servertime: number
  obtainedAt: number
}

/** Per-team live stats from the 0x02 binary frame. */
export interface TeamStat {
  level: number
  open: boolean
  crystals: number
}

interface Profile {
  player_name: string
  hue: number
  custom: PlayerCustom | null
  friendly: number
}

export interface RelayState {
  modeInfo: RelayModeInfo | null
  /** Server-generated asteroid grid (once modeInfo arrives). */
  asteroidGrid: string | null
  /** Live players (real positions + profiles). */
  players: Player[] | null
  /** Team stats (level / gems) from the 0x02 frame. */
  teamStats: TeamStat[] | null
  connected: boolean
  enabled: boolean
}

/** Subscribe to a single system via the dankdmitron relay.
 *  compositeId must be in `"<id>@<ip>:<port>"` format (= GameEntry.key).
 *  Only works for team-mode systems — the relay only spectates those. */
export function useGameRelay(compositeId: string | null): RelayState {
  const [modeInfo, setModeInfo] = useState<RelayModeInfo | null>(null)
  const [asteroidGrid, setAsteroidGrid] = useState<string | null>(null)
  const [players, setPlayers] = useState<Player[] | null>(null)
  const [teamStats, setTeamStats] = useState<TeamStat[] | null>(null)
  const [connected, setConnected] = useState(false)
  const wsRef = useRef<WebSocket | null>(null)

  useEffect(() => {
    if (!RELAY_URL || !compositeId) return
    setModeInfo(null)
    setAsteroidGrid(null)
    setPlayers(null)
    setTeamStats(null)

    const profiles = new Map<number, Profile>()
    const requested = new Set<number>()
    let raf = 0
    let latest: Player[] = []

    const ws = new WebSocket(RELAY_URL)
    ws.binaryType = 'arraybuffer'
    wsRef.current = ws

    const flush = () => { setPlayers(latest); raf = 0 }
    const schedule = () => { if (!raf) raf = requestAnimationFrame(flush) }

    ws.onopen = () => {
      setConnected(true)
      ws.send(JSON.stringify({ name: 'subscribe', data: { id: compositeId } }))
    }

    ws.onmessage = (e) => {
      // ── JSON messages ──────────────────────────────────────────────
      if (typeof e.data === 'string') {
        let msg: { name: string; data: Record<string, unknown> }
        try { msg = JSON.parse(e.data) } catch { return }

        if (msg.name === 'mode_info') {
          const d = msg.data as Record<string, unknown>
          const mode = d.mode as Record<string, unknown> | undefined
          const teams = ((mode?.teams as Array<Record<string, unknown>>) || []).map((t) => ({
            hue: (t.hue as number) ?? 0,
            phase: ((t.station as Record<string, number> | undefined)?.phase) ?? 0,
          }))
          const info: RelayModeInfo = {
            seed: d.seed as number,
            mapSize: (mode?.map_size as number) || 80,
            modeId: (mode?.id as string) || 'team',
            teams,
            servertime: (d.servertime as number) ?? 0,
            obtainedAt: Date.now(),
          }
          setModeInfo(info)

          // Generate the asteroid grid from the seed (runs once, CPU-bound ~50ms)
          try {
            const rootMode = info.modeId === 'modding'
              ? ((mode?.root_mode as string) || 'survival')
              : info.modeId
            const customMap = mode?.custom_map as string | undefined
            const grid = customMap || getMap(info.seed, info.mapSize, rootMode)
            setAsteroidGrid(grid)
          } catch (err) {
            console.warn('[relay] map gen failed', err)
          }
        }

        if (msg.name === 'player_name') {
          const d = msg.data as Record<string, unknown>
          profiles.set(d.id as number, {
            player_name: d.player_name as string,
            hue: (d.hue as number) ?? 0,
            custom: (d.custom as PlayerCustom | null) ?? null,
            friendly: (d.friendly as number) ?? 0,
          })
        }
        return
      }

      // ── Binary frames ──────────────────────────────────────────────
      const view = new DataView(e.data as ArrayBuffer)
      const type = view.getUint8(0)

      if (type === 0x01) {
        // Ship snapshot: id(u8) x(f32) y(f32) score(u32) flags(u16)
        const out: Player[] = []
        for (let off = 1; off <= view.byteLength - 15; off += 15) {
          const id = view.getUint8(off)
          const v = view.getUint16(off + 13, true)
          const prof = profiles.get(id)
          if (!prof && !requested.has(id)) {
            requested.add(id)
            try { ws.send(JSON.stringify({ name: 'get_name', data: { id } })) } catch { /* noop */ }
          }
          out.push({
            id,
            x: view.getFloat32(off + 1, true),
            y: view.getFloat32(off + 5, true),
            score: view.getUint32(off + 9, true),
            isAlive: (v & (1 << 15)) !== 0,
            ship: v & ~(1 << 15),
            player_name: prof?.player_name ?? '',
            hue: prof?.hue ?? 0,
            custom: prof?.custom ?? null,
            friendly: prof?.friendly ?? 0,
            kills: 0,
          })
        }
        latest = out
        schedule()
        return
      }

      if (type === 0x02) {
        // Team snapshot: flags(u8) crystals(u32)
        const stats: TeamStat[] = []
        for (let off = 1; off <= view.byteLength - 5; off += 5) {
          const flags = view.getUint8(off)
          stats.push({
            level: flags & 0x0f,
            open: (flags & 0xf0) !== 0,
            crystals: view.getUint32(off + 1, true),
          })
        }
        setTeamStats(stats)
      }
    }

    ws.onclose = () => setConnected(false)
    ws.onerror = () => setConnected(false)

    return () => {
      if (raf) cancelAnimationFrame(raf)
      try { ws.close() } catch { /* noop */ }
      wsRef.current = null
    }
  }, [compositeId])

  return { modeInfo, asteroidGrid, players, teamStats, connected, enabled: !!RELAY_URL }
}
